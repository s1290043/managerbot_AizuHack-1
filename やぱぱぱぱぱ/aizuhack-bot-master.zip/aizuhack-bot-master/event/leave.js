// 退出イベントが飛んできた時
export default () => {
  // ログに出力
  console.log('botがグループから退出しました');
};
